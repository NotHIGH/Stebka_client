/*
Minetest
Copyright (C) 2010-2013 celeron55, Perttu Ahola <celeron55@gmail.com>
Copyright (C) 2017 nerzhul, Loic Blot <loic.blot@unix-experience.fr>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 3.0 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
*/

#pragma once

#include <vector>
#include <memory>
#include <string>
#include "irrlichttypes_extrabloated.h"
#include "debug.h"

class ITextureSource;
class Camera;
class Client;
class LocalPlayer;
class Hud;
class Minimap;
class GUIButton;

class RenderingCore;

class RenderingEngine
{
public:
	RenderingEngine(IEventReceiver *eventReceiver);
	~RenderingEngine();

	v2u32 getWindowSize() const;
	void setResizable(bool resize);

	video::IVideoDriver *getVideoDriver() { return driver; }

	static const char *getVideoDriverName(irr::video::E_DRIVER_TYPE type);
	static const char *getVideoDriverFriendlyName(irr::video::E_DRIVER_TYPE type);
	static float getDisplayDensity();
	static float getScreenScale();
	static float getHudScaling();
	static v2u32 getDisplaySize();
	static int getWindowSafeArea();
#ifdef HAVE_TOUCHSCREENGUI
	static bool isTablet();
#endif
	static bool isHighDpi();
	static void startTextInput();
	static void stopTextInput();

	bool setupTopLevelWindow(const std::string &name);
	void setupTopLevelXorgWindow(const std::string &name);
	bool setWindowIcon();
	bool setXorgWindowIconFromPath(const std::string &icon_file);
	static bool print_video_modes();

	static RenderingEngine *get_instance() { return s_singleton; }

	static io::IFileSystem *get_filesystem()
	{
		sanity_check(s_singleton && s_singleton->m_device);
		return s_singleton->m_device->getFileSystem();
	}

	static video::IVideoDriver *get_video_driver()
	{
		sanity_check(s_singleton && s_singleton->m_device);
		return s_singleton->m_device->getVideoDriver();
	}

	static scene::IMeshCache *get_mesh_cache()
	{
		sanity_check(s_singleton && s_singleton->m_device);
		return s_singleton->m_device->getSceneManager()->getMeshCache();
	}

	static scene::ISceneManager *get_scene_manager()
	{
		sanity_check(s_singleton && s_singleton->m_device);
		return s_singleton->m_device->getSceneManager();
	}

	static irr::IrrlichtDevice *get_raw_device()
	{
		sanity_check(s_singleton && s_singleton->m_device);
		return s_singleton->m_device;
	}

	static u32 get_timer_time()
	{
		sanity_check(s_singleton && s_singleton->m_device &&
				s_singleton->m_device->getTimer());
		return s_singleton->m_device->getTimer()->getTime();
	}

	static gui::IGUIEnvironment *get_gui_env()
	{
		sanity_check(s_singleton && s_singleton->m_device);
		return s_singleton->m_device->getGUIEnvironment();
	}

	inline static void draw_load_screen(const std::wstring &text,
			gui::IGUIEnvironment *guienv, ITextureSource *tsrc,
			float dtime = 0, int percent = 0)
	{
		s_singleton->_draw_load_screen(
				text, guienv, tsrc, dtime, percent);
	}

	inline static void draw_load_cleanup()
	{
		s_singleton->_draw_load_cleanup();
	}

	inline static void set_load_screen_cancel(bool *flag)
	{
		if (s_singleton)
			s_singleton->m_load_cancel = flag;
	}

	inline static void cancel_load_screen()
	{
		if (s_singleton && s_singleton->m_load_cancel)
			*s_singleton->m_load_cancel = true;
	}

	//! Feeds a tap to the cancel button, which the GUI cannot reach on its own
	static bool handle_load_screen_touch(const SEvent &event);

	inline static void draw_menu_scene(
			gui::IGUIEnvironment *guienv, ITextureSource *tsrc,
			float dtime)
	{
		s_singleton->_draw_menu_scene(guienv, tsrc, dtime);
	}

	inline static void draw_scene(video::SColor skycolor, bool show_hud,
			bool show_minimap, bool draw_wield_tool, bool draw_crosshair, bool draw_nametags)
	{
		s_singleton->_draw_scene(skycolor, show_hud, show_minimap,
				draw_wield_tool, draw_crosshair, draw_nametags);
	}

	inline static void initialize(Client *client, Hud *hud)
	{
		s_singleton->_initialize(client, hud);
	}

	inline static void finalize() { s_singleton->_finalize(); }

	inline static void clear_irrlicht_texture_cache() { s_singleton->_clear_irrlicht_texture_cache(); }

	static bool run()
	{
		sanity_check(s_singleton && s_singleton->m_device);
		return s_singleton->m_device->run();
	}

	static std::vector<core::vector3d<u32>> getSupportedVideoModes();
	static std::vector<irr::video::E_DRIVER_TYPE> getSupportedVideoDrivers();

	static void setLoadScreenBackground(const bool clouds, const std::string texture,
			const video::SColor sky_color)
	{
		if (s_singleton) {
			s_singleton->m_load_bg_clouds = clouds;
			s_singleton->m_load_bg_texture = texture;
			s_singleton->m_sky_color = sky_color;
		}
	}

private:
	void _draw_load_screen(const std::wstring &text, gui::IGUIEnvironment *guienv,
			ITextureSource *tsrc, float dtime = 0, int percent = 0);

	void _draw_menu_scene(gui::IGUIEnvironment *guienv,
			ITextureSource *tsrc, float dtime = 0);

	void _draw_load_bg(gui::IGUIEnvironment *guienv,
			ITextureSource *tsrc, float dtime = 0);

	void _draw_scene(video::SColor skycolor, bool show_hud, bool show_minimap,
			bool draw_wield_tool, bool draw_crosshair, bool draw_nametags);

	void _draw_load_cleanup();

	void _initialize(Client *client, Hud *hud);

	void _finalize();

	void _clear_irrlicht_texture_cache();

	std::unique_ptr<RenderingCore> core;
	irr::IrrlichtDevice *m_device = nullptr;
	irr::video::IVideoDriver *driver;
	static RenderingEngine *s_singleton;

	gui::IGUIStaticText *m_load_text = nullptr;
	gui::IGUIElement *m_load_root = nullptr;
	GUIButton *m_load_button = nullptr;
	bool *m_load_cancel = nullptr;

	bool m_load_bg_clouds = false;
	std::string m_load_bg_texture = "";
	video::SColor m_sky_color;
	u64 m_last_time = 0;
	float m_load_screen_dtime = 0;
	bool m_load_screen_drawn = false;
	int m_percent = 0;
	float m_percent_shown = 0.0f;
};

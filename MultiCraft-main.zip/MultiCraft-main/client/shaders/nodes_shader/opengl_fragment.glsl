uniform sampler2D baseTexture;

uniform vec4 skyBgColor;
uniform mediump float fogDistance;

varying vec3 vPosition;
// World position in the visible world (i.e. relative to the cameraOffset.)
// This can be used for many shader effects without loss of precision.
// If the absolute position is required it can be calculated with
// cameraOffset + worldPosition (for large coordinates the limits of float
// precision must be considered).
varying vec3 worldPosition;
varying lowp vec4 varColor;
#ifdef GL_ES
varying mediump vec2 varTexCoord;
#else
centroid varying vec2 varTexCoord;
#endif
varying vec3 eyeVec;
#if POINT_LIGHTS
varying float vShade;
varying vec3 vRelPos;

// Light sources, one per column: xyz relative to the eye, w = level / 15
uniform mat4 pointLights;
// Maximum with a rounded corner, a plain max() shows the rim as a crease
vec3 softMax(vec3 a, vec3 b)
{
	const float k = 0.08;
	vec3 h = clamp(0.5 + 0.5 * (b - a) / k, 0.0, 1.0);
	return mix(a, b, h) + k * h * (1.0 - h);
}

vec3 pointLight(vec4 light)
{
	if (light.w <= 0.0)
		return vec3(0.0);
	vec3 dir = light.xyz - vRelPos;
	// One level per node, like spreading node light, but round
	float level = light.w - length(dir) / 150.0;
	if (level <= 0.0)
		return vec3(0.0);
	// Brightness of that level, mirrors decode_light_f() in light.cpp
	float lit = ((LIGHT_CURVE.x * level + LIGHT_CURVE.y) * level + LIGHT_CURVE.z) * level;
	float spread = level - LIGHT_BOOST.y;
	lit += LIGHT_BOOST.x * exp(LIGHT_BOOST.z * spread * spread);
	lit = clamp(lit, 0.0, 1.0);
	if (LIGHT_CURVE.w != 1.0)
		lit = pow(lit, LIGHT_CURVE.w);
	return vec3(lit * vShade * LIGHT_SCALE);
}
#endif

const float fogStart = FOG_START;
const float fogShadingParameter = 1.0 / ( 1.0 - fogStart);

#if ENABLE_TONE_MAPPING

/* Hable's UC2 Tone mapping parameters
	A = 0.12;
	B = 0.30;
	C = 0.10;
	D = 0.20;
	E = 0.01;
	F = 0.30;
	W = 11.2;
	equation used:  ((x * (A * x + C * B) + D * E) / (x * (A * x + B) + D * F)) - E / F
*/

vec3 uncharted2Tonemap(vec3 x)
{
	return ((x * (0.12 * x + 0.03) + 0.002) / (x * (0.12 * x + 0.3) + 0.06)) - 0.03333;
}

vec4 applyToneMapping(vec4 color)
{
	color = vec4(pow(color.rgb, vec3(2.2)), color.a);
	const float gamma = 1.6;
	const float exposureBias = 5.5;
	color.rgb = uncharted2Tonemap(exposureBias * color.rgb);
	// Precalculated white_scale from
	//vec3 whiteScale = 1.0 / uncharted2Tonemap(vec3(W));
	vec3 whiteScale = vec3(1.25);
	color.rgb *= whiteScale;
	return vec4(pow(color.rgb, vec3(1.0 / gamma)), color.a);
}
#endif

void main(void)
{
	vec3 color;
	vec2 uv = varTexCoord.st;

	vec4 base = texture2D(baseTexture, uv).rgba;
#ifdef USE_DISCARD
	// If alpha is zero, we can just discard the pixel. This fixes transparency
	// on GPUs like GC7000L, where GL_ALPHA_TEST is not implemented in mesa,
	// and also on GLES 2, where GL_ALPHA_TEST is missing entirely.
	if (base.a == 0.0) {
		discard;
	}
#endif

#ifdef USE_ALPHA_TEST_DISCARD
	if (base.a < 0.5) {
		discard;
	}
#endif

	color = base.rgb;

	vec3 lightColor = varColor.rgb;
#if POINT_LIGHTS
	for (int i = 0; i < POINT_LIGHTS; i++) {
		vec3 lit = pointLight(pointLights[i]);
		if (lit.r > 0.0)
			lightColor = softMax(lightColor, lit);
	}
	lightColor = min(lightColor, vec3(1.0));
#endif

	vec4 col = vec4(color.rgb * lightColor, 1.0);

#if ENABLE_TONE_MAPPING
	col = applyToneMapping(col);
#endif

	// Due to a bug in some (older ?) graphics stacks (possibly in the glsl compiler ?),
	// the fog will only be rendered correctly if the last operation before the
	// clamp() is an addition. Else, the clamp() seems to be ignored.
	// E.g. the following won't work:
	//      float clarity = clamp(fogShadingParameter
	//		* (fogDistance - length(eyeVec)) / fogDistance), 0.0, 1.0);
	// As additions usually come for free following a multiplication, the new formula
	// should be more efficient as well.
	// Note: clarity = (1 - fogginess)
	if (fogDistance > 0.0) { // -1.0 means disabled
		float clarity = clamp(fogShadingParameter
			- fogShadingParameter * length(eyeVec), 0.0, 1.0);
		col = mix(skyBgColor, col, clarity);
	}
	col = vec4(col.rgb, base.a);

	gl_FragColor = col;
}
